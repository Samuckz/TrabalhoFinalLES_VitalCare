# TrabalhoFinalLES_VitalCare
Trabalho realizado para a disciplina de Laboratório de Engenharia de Software do curso de Engenharia da Computação do CEFET MG
