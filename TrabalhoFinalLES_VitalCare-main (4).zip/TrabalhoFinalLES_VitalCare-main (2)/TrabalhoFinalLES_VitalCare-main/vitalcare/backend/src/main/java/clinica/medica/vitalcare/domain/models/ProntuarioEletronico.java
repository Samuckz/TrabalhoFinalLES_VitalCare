package clinica.medica.vitalcare.domain.models;

public class ProntuarioEletronico {
    private String anamnese;
    private String medicamentos;
    private String atestados;
    private String exames;
}
