package clinica.medica.vitalcare.domain.dtos.Pessoa;

public record PessoaResponseDto(String nome, String email) {
}
