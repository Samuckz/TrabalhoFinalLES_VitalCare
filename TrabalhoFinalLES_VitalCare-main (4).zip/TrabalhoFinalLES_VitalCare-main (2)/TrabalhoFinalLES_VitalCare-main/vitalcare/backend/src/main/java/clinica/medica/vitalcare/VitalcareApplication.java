package clinica.medica.vitalcare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VitalcareApplication {

	public static void main(String[] args) {
		SpringApplication.run(VitalcareApplication.class, args);
	}

}
