package clinica.medica.vitalcare.utils.enums;

public enum Especialidade {
    CARDIOLOGIA,
    DERMATOLOGIA,
    GINECOLOGIA,
    PEDIATRIA,
    PSIQUIATRIA,
    ORTOPEDIA,
    OFTALMOLOGIA,
    NEUROLOGIA,
    UROLOGIA,
    ONCOLOGIA
}
