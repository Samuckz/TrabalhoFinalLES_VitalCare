package clinica.medica.vitalcare.utils.exceptions.tratadores;

public class ValidationException extends RuntimeException {
    public ValidationException(String s) {
        super(s);
    }
}
