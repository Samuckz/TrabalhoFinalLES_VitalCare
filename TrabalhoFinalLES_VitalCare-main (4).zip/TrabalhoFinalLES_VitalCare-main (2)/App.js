document.addEventListener("DOMContentLoaded", function() {
    const enderecoForm = document.getElementById("enderecoForm");

    enderecoForm.addEventListener("submit", function(event) {
        event.preventDefault();

        
        const cep = document.getElementById("cep").value;
        const logradouro = document.getElementById("logradouro").value;
        const bairro = document.getElementById("bairro").value;
        const cidade = document.getElementById("cidade").value;
        const estado = document.getElementById("estado").value;

        
        fetch('/endereco/cadastrar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                cep: cep,
                logradouro: logradouro,
                bairro: bairro,
                cidade: cidade,
                estado: estado,
            }),
        })
        .then(response => response.json())
        .then(data => {
            console.log('Success:', data);
            
            alert('Endereço cadastrado com sucesso!');
        })
        .catch((error) => {
            console.error('Error:', error);
            
            alert('Erro ao cadastrar endereço. Verifique os dados e tente novamente.');
        });
    });
});
